package netns

const (
	SYS_SETNS = 308
)
