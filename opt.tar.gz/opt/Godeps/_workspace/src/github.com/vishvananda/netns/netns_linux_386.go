package netns

const (
	SYS_SETNS = 346
)
